#!/bin/bash

# Verify
zokrates verify --verification-key-path build/verification.key --proof-path build/proof.json

